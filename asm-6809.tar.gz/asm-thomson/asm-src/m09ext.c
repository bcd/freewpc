/* M09EXT:C */

/*
 * (C) Copyright 1989,1990
 * All Rights Reserved
 *
 * Alan R. Baldwin
 * 721 Berkeley St.
 * Kent, Ohio  44240
 */

#include <stdio.h>
#include <setjmp.h>
#include "asm.h"

char	*cpu	= "Motorola 6809";
char	*dsft	= "ASM";
int	hilo	= 1;
